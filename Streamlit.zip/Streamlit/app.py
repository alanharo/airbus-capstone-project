### Disclaimer: This document has been developed using Copilot and Chat GPT from Open AI.###

#Import Python libraries
import streamlit as st
from PIL import Image
import pandas as pd
import numpy as np
import time
import matplotlib.pyplot as plt

def main(): 
    
    #Display page title
    st.set_page_config(page_title = 'AIRBUS Fuel Leakage Monitoring')
    
    # Display logo
    image = Image.open('C:/Users/catta/Desktop/Studium/Capstone/Streamlit/logo-airbus.jpeg')
    st.image(image, use_column_width=True)
    ### Source of the image: https://www.airbus.com/en
    
    #Load data 
    path = 'streamlit-data.csv'
    parse_dates = ['UTC_TIME']
    df = pd.read_csv(path, sep=',', parse_dates=parse_dates)
    df['Date'] = df['UTC_TIME'].dt.date
    
    #Create a dataframe with one row for each flight
    all_flights = df.groupby('id').agg({'Type': 'first', 'Date': 'max', 'ArrivalAirport': 'first', 'Airline': 'first', 'Region': 'first', 'FUEL_ERROR': 'last', 'Leak': 'first'}).rename(columns={'FUEL_ERROR': 'LeakageAmount'})
    all_flights['Leak'] = all_flights['Leak'].astype(int)
    all_flights['AircraftRegistrationNumber'] = all_flights.index.str[:6]
    all_flights['FlightNumber'] = all_flights.index.str[7:]
    
    #Create a dataframe only containing the flights with leak
    flights_with_leaks = all_flights[all_flights['Leak'] == 1]
    flights_with_leaks.reset_index(inplace=True)

    # Add sidebar selection options
    default_types = ['A220', 'A320', 'A330', 'A350', 'A380']
    types = sorted(list(set(flights_with_leaks['Type'].unique().tolist() + default_types)))
    
    default_regions = ['EMEA', 'AMERICA', 'APAC']
    regions = sorted(list(set(flights_with_leaks['Region'].unique().tolist() + default_regions)))
    
    dates = flights_with_leaks['Date'].unique().tolist()  

    with st.sidebar:
        date_selection = st.slider(
            "Dates",
            min_value = min(dates),
            max_value = max(dates),
            value = (min(dates),max(dates)),
        )     

        region_selection = st.radio(
            "Geographical Area",
            regions
        )    

        type_selection = st.selectbox(
            "Type of Aircraft",
            types
        )

    #Filter the data to be displayed according to the selection   
    filtered_all_flights = all_flights[(all_flights['Date'] >= date_selection[0]) & (all_flights['Date'] <= date_selection[1]) & (all_flights['Region'] == region_selection) & (all_flights['Type'] == type_selection)]
    
    filtered_flights_with_leaks = flights_with_leaks[(flights_with_leaks['Date'] >= date_selection[0]) & (flights_with_leaks['Date'] <= date_selection[1]) & (flights_with_leaks['Region'] == region_selection) & (flights_with_leaks['Type'] == type_selection)]
    
    #Create a dataframe that shows the number of flights with leak and without leak
    filtered_label_counts = filtered_all_flights.groupby('Leak').size()
    
    #Obtain the value of total leakage for the flights with leaks that fall into the selection
    filtered_leakage_amount = filtered_flights_with_leaks['LeakageAmount'].sum()
    
    #Display title
    st.markdown(
        """
        <style>
        .title {
            color: #0B2057;
            font-size:45px;
            text-align: center;
        }
        </style>
        """,
        unsafe_allow_html=True
    )
    st.markdown('<h1 class="title">Live Fuel Leakage Monitoring</h1>', unsafe_allow_html=True)

    #Empty spacing for layout design
    st.text("")
    st.text("") 
        
    #Display KPIs
    col1, col2, col3 = st.columns(3)
    col1.metric("Aircrafts with Leak", f"{filtered_label_counts[1]}/{filtered_label_counts[0]+filtered_label_counts[1]}")
    col2.metric("Total Downtime", f"{filtered_label_counts[1]*4} hours")
    col3.metric("Fuel Wasted", f"{int(filtered_leakage_amount/1000)} tons")
    

    # Display number of flights with leakages with blinking effect
    status = st.empty()
    blink_status = """
    <h1 style="color: red; animation: blinker 1s linear infinite; text-align: center;">
        {} Leakages Detected
    </h1>
    <style>
        @keyframes blinker {{
            50% {{
                opacity: 0;
            }}
        }}
    </style>
    """
    blink_status_with_variable = blink_status.format(filtered_label_counts[1])
    status.empty()
    status.markdown(blink_status_with_variable, unsafe_allow_html=True) 

   #Display table listing aircrafts with leakages that fall into the selection
    table_flights_with_leaks = filtered_flights_with_leaks
    table_flights_with_leaks['Check'] = False 
    table_flights_with_leaks = table_flights_with_leaks[['Check',
                                                         'AircraftRegistrationNumber',
                                                         'FlightNumber', 
                                                         'Airline', 
                                                         'Date', 
                                                         'ArrivalAirport', 
                                                         'LeakageAmount']].rename(columns={
        'AircraftRegistrationNumber': 'Aircraft Reg. Number',
        'FlightNumber': 'Flight',
        'ArrivalDate': 'Arrival Date',
        'ArrivalAirport': 'Arrival Airport',
        'LeakageAmount': 'Leakage [kg]'
    })
    #Obtain the data of the flight that the users selected by ticking the checkbox
    selected_flight = st.data_editor(
        table_flights_with_leaks,
        column_config={
            "Check": st.column_config.CheckboxColumn(
                "",
                help="Select the **flight** you want to inspect",
                default=False,
            )
        },
        disabled=["widgets"],
        hide_index=True,
    )
    
    selected_flight = selected_flight[selected_flight['Check'] == True]
    selected_flight['id'] = selected_flight['Aircraft Reg. Number']+'_'+selected_flight['Flight']
    selected_flight.reset_index(inplace = True)   
    
    #If the user selected a flight by ticking the checkbox, display the fuel details of the flight
    if selected_flight.shape[0] != 0:
    
        #Empty spacing for layout design
        st.text("")
        st.text("") 
        
        df_selected_flight = df[df['id'] == selected_flight['id'][0]]

        #Display a line chart that displays the fuel details of the selected flight
        fig, ax = plt.subplots()
        ax.plot(df_selected_flight['duration'], df_selected_flight['FUEL_DEPLETION'], color='red', label='Fuel Depleted')
        ax.plot(df_selected_flight['duration'], df_selected_flight['FUEL_USED_TOT'], color='blue', label='Total Fuel Used')

        #Define chart title and labels
        title = 'Aircraft: ' + selected_flight['Aircraft Reg. Number'][0] + ' Flight: ' + selected_flight['Flight'][0]
        plt.title(title)
        ax.set_xlabel('Flight Duration [seconds]')
        ax.set_ylabel('Fuel Quantity [kg]')

        #Display legend
        ax.legend()
        
        #Display chart
        st.pyplot(fig)
    
if __name__ == "__main__":
    main()