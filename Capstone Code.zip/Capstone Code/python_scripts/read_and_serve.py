# Script that defines a function to later be called by the main Notebook
# Function reads the data from the csv file and serves it to the main Notebook

# Importing libraries
import pandas as pd
from icecream import ic
import time
import warnings
warnings.filterwarnings('ignore')

# Defining function
def read_and_serve(path, columns, columns_dtypes, minutes):
    parse_dates = ['UTC_TIME']

    # Read the file
    df = pd.read_csv(path, usecols=columns, dtype=columns_dtypes, sep=';', parse_dates=parse_dates)

    # Sort values by MSN, Flight and UTC_TIME
    df.sort_values(by=['MSN', 'Flight', 'UTC_TIME'], inplace=True)

    # Fill missing values, for PHASE_COUNT we will use 0;
    df = df[df['FLIGHT_PHASE_COUNT']==8]

    # We will take the first reading of each minute. We are doing this to decrease
    # the file size. Since it is accumulated we only need the first reading of each
    # minute. We will use the UTC_TIME column to group by.
    if minutes:
        df = (df.groupby(['Flight', 'MSN',
                                  pd.Grouper(key='UTC_TIME', freq='1min')]).first().reset_index())

    # We will now iterate for the Phase columns and Flight columns
    # to fill the missing values
    iter = 1
    df_all = pd.DataFrame()
    start_time = time.time()
    for phase in df['FLIGHT_PHASE_COUNT'].unique():
        for flight in df['Flight'].unique():
            df_temp = df.loc[(df['FLIGHT_PHASE_COUNT'] == phase) & (df['Flight'] == flight)]
            df_temp['FUEL_USED_1'] = df_temp['FUEL_USED_1'].fillna(df_temp['FUEL_USED_1'].mean())
            df_temp['FUEL_USED_2'] = df_temp['FUEL_USED_2'].fillna(df_temp['FUEL_USED_2'].mean())
            df_temp['FUEL_USED_3'] = df_temp['FUEL_USED_3'].fillna(df_temp['FUEL_USED_3'].mean())
            df_temp['FUEL_USED_4'] = df_temp['FUEL_USED_4'].fillna(df_temp['FUEL_USED_4'].mean())
            df_temp['VALUE_FOB'] = df_temp['VALUE_FOB'].fillna(df_temp['VALUE_FOB'].mean())
            df_temp['FW_GEO_ALTITUDE'] = df_temp['FW_GEO_ALTITUDE'].interpolate(method='linear')
            # df_temp['VALUE_FUEL_QTY_CT'] = df_temp['VALUE_FUEL_QTY_CT'].interpolate(method='linear')
            # df_temp['VALUE_FUEL_QTY_RXT'] = df_temp['VALUE_FUEL_QTY_RXT'].interpolate(method='linear')
            # df_temp['VALUE_FUEL_QTY_LXT'] = df_temp['VALUE_FUEL_QTY_LXT'].interpolate(method='linear')
            # df_temp['VALUE_FUEL_QTY_FT1'] = df_temp['VALUE_FUEL_QTY_FT1'].interpolate(method='linear')
            # df_temp['VALUE_FUEL_QTY_FT2'] = df_temp['VALUE_FUEL_QTY_FT2'].interpolate(method='linear')
            # df_temp['VALUE_FUEL_QTY_FT3'] = df_temp['VALUE_FUEL_QTY_FT3'].interpolate(method='linear')
            # df_temp['VALUE_FUEL_QTY_FT4'] = df_temp['VALUE_FUEL_QTY_FT4'].interpolate(method='linear')

            df_all = pd.concat([df_all, df_temp])
            progress = (iter
                        / (len(df['FLIGHT_PHASE_COUNT'].unique())
                           * len(df['Flight'].unique())) * 100)
            progress_str = f'Progress: {progress:.2f}%'
            ic(progress_str)
            iter += 1

    # Group by minute:

    end_time = time.time()
    # elapsed_time = end_time - start_time
    # elapsed_time_str = f'Elapsed time: {elapsed_time:.2f} seconds'
    # ic(elapsed_time_str)
    # We will define the output path and save the file
    output_path = path.replace('raw_', 'prep_').replace('_fuel_leak_signals_preprocessed'
                                                        , '_prep')
    df_all.to_csv(output_path)

    # We will now calculate for each column the difference between the current
    # value and the previous value. We will do this for all the columns except
    # for the columns that are not accumulated metrics.
    # We will replace all the columns and save on a new file.
    df_diff = df_all.copy()
    df_diff.sort_values(by=['MSN', 'Flight', 'UTC_TIME'], inplace=True)
    df_all_diff = pd.DataFrame()
    col_names = ['FUEL_USED_1', 'FUEL_USED_2', 'FUEL_USED_3', 'FUEL_USED_4',
                 'VALUE_FOB', 'FW_GEO_ALTITUDE']
                 # 'VALUE_FUEL_QTY_CT', 'VALUE_FUEL_QTY_RXT', 'VALUE_FUEL_QTY_LXT',
                 #  'VALUE_FUEL_QTY_FT1', 'VALUE_FUEL_QTY_FT2',
                 # 'VALUE_FUEL_QTY_FT3', 'VALUE_FUEL_QTY_FT4']

    start_time = time.time()
    iter = 1
    for flight in df_diff['Flight'].unique():
        # We will track time for each iteration
        df_temp = df_diff.loc[df_diff['Flight'] == flight]
        df_temp['FUEL_USED_1'] = df_temp['FUEL_USED_1'].diff()
        df_temp['FUEL_USED_2'] = df_temp['FUEL_USED_2'].diff()
        df_temp['FUEL_USED_3'] = df_temp['FUEL_USED_3'].diff()
        df_temp['FUEL_USED_4'] = df_temp['FUEL_USED_4'].diff()
        df_temp['VALUE_FOB'] = df_temp['VALUE_FOB'].diff()
        df_temp['FW_GEO_ALTITUDE'] = df_temp['FW_GEO_ALTITUDE'].diff()

        # df_temp['VALUE_FUEL_QTY_CT'] = df_temp['VALUE_FUEL_QTY_CT'].diff()
        # df_temp['VALUE_FUEL_QTY_RXT'] = df_temp['VALUE_FUEL_QTY_RXT'].diff()
        # df_temp['VALUE_FUEL_QTY_LXT'] = df_temp['VALUE_FUEL_QTY_LXT'].diff()
        # df_temp['VALUE_FUEL_QTY_FT1'] = df_temp['VALUE_FUEL_QTY_FT1'].diff()
        # df_temp['VALUE_FUEL_QTY_FT2'] = df_temp['VALUE_FUEL_QTY_FT2'].diff()
        # df_temp['VALUE_FUEL_QTY_FT3'] = df_temp['VALUE_FUEL_QTY_FT3'].diff()
        # df_temp['VALUE_FUEL_QTY_FT4'] = df_temp['VALUE_FUEL_QTY_FT4'].diff()


        df_all_diff = pd.concat([df_all_diff, df_temp])


        progress = (iter/len(df_diff['Flight'].unique()) * 100)
        progress_str = f'Progress: {progress:.2f}%'
        ic(progress_str)

        iter += 1

    end_time = time.time()
    # total_time_sec = end_time - start_time
    # total_time_str = f'Total time: {total_time_sec:.2f} seconds'
    # ic(total_time_str)

    # We will add the _DIFF suffix to the column names with exception of
    # UTC_TIME, MSN, FLIGHT_PHASE_COUNT and Flight
    for col in col_names:
        df_all_diff.rename(columns={col: col + '_DIFF'}, inplace=True)

    df_all_diff.dropna(inplace=True)

    # We will define the output path and save the file
    output_path_diff = output_path.replace('_prep', '_prep_diff')
    df_all_diff.to_csv(output_path_diff)
    print("Done!")