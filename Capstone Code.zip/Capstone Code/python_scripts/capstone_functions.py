# Script that defines a function to later be called by the main Notebook
# Function reads the data from the csv file and serves it to the main Notebook

# Importing libraries
import pandas as pd
import numpy as np
from functools import reduce
from icecream import ic
import time
import warnings

from sklearn.linear_model import LinearRegression

from statsmodels.tsa.stattools import adfuller
from scipy.stats import norm

warnings.filterwarnings('ignore')


# Defining functions
def read_and_prepare(file_path: str,
                     columns: list,
                     column_dtypes={},
                     delimiter=',',
                     parse_dates=[],
                     phase_filter=[8],
                     altitude_filter=False):
    """
    Function that reads the data from the csv file and serves it to the main Notebook
    :param file_path: file path to the csv file
    :param columns: columns to be read from the csv file
    :param column_dtypes: data types of the columns to be read from the csv file
    :param delimiter: delimiter of the csv file
    :param parse_dates: columns to be parsed as dates
    :param phase_filter: phases to be filtered
    :param altitude_filter: boolean to filter the data by altitude mean
    :return: df: pandas DataFrame with the data
    """
    # Reading the data
    df = pd.read_csv(file_path, usecols=columns, dtype=column_dtypes, delimiter=delimiter,
                     parse_dates=parse_dates)

    # Filtering for the phases
    df = df[df['FLIGHT_PHASE_COUNT'].isin(phase_filter)]

    # Setting the index
    df['id'] = df['MSN'] + '_' + df['Flight']

    # Filter for each flight keeping the values above 25000 feet of altitude
    if altitude_filter:
        df = df[df['FW_GEO_ALTITUDE'] > 23000]

    # Add duration column to the dataframe as the difference between the first utc_time
    # and the current utc_time
    df['duration'] = df.groupby('id')[parse_dates[0]].apply(lambda x: (x - x.min()).dt.total_seconds())

    # Drop the columns used as index
    df.drop(columns=['MSN', 'Flight'], inplace=True)

    # Sort values by id and UTC_TIME
    df.sort_values(by=['id', parse_dates[0]], inplace=True)

    return df


def keep_usable_flights(df: pd.DataFrame,
                        id_column='id',
                        value_columns=[],
                        threshold=0):
    """
    Function that keeps only the flights that have a minimum number of non NAN rows
    :param df: DataFrame with the data
    :param id_column: columns to be grouped by
    :param value_columns: value columns to be checked
    :param threshold: minimum number of non NAN rows
    :return: filtered_df: DataFrame with the data filtered
    """

    # Grouping the data
    df_count = df.groupby(id_column).count().reset_index()
    df_count['condition'] = df_count[value_columns].apply(lambda x: (x > threshold).all(), axis=1)
    valid_ids = df_count[df_count['condition']][id_column].values.tolist()

    df_filtered = df[df[id_column].isin(valid_ids)]

    return df_filtered


def fill_missing_values(df: pd.DataFrame,
                        column_x: list,
                        column_y: str):
    """
    Function that fills the missing values of a column using a linear regression
    :param df: DataFrame with the data
    :param column_x: column name with the values to be used as X
    :param column_y: column name with the values to be used as y
    :return: column_y_filled: column with the missing values filled
    """
    # We will create a dataframe with the rows that do not have a missing value for the column
    df_not_null = df[df[column_y].notnull()]

    # We will create a dataframe with the rows that have a missing value for the column
    df_null = df[df[column_y].isnull()]
    null_shape = df_null.shape[0]

    # We will create the X and y variables for the linear regression

    X = df_not_null[column_x]
    y = df_not_null[column_y]

    # We will create the linear regression model
    model = LinearRegression()

    # We will fit the model
    model.fit(X, y)

    # If no missing values, we will return the original column
    if null_shape == 0:
        return df[column_y]
    else:
        # We will predict the values for the missing values
        y_pred = model.predict(df_null[column_x])

        # We will add the predicted values to the dataframe
        df_null[column_y] = y_pred

        # We will concatenate the dataframes
        column_y_filled = pd.concat([df_not_null, df_null], axis=0)[column_y]
        return column_y_filled


def fill_missing_values_all_flights(df,
                                    use_qty_cols=False,
                                    use_altitude_col=False,
                                    use_value_fob_col=False,
                                    show_logs=False):
    """
    Function that iterates through the 'id' of the flights and fills the missing values of the columns
    :param df: dataframe to iterate
    :param use_qty_cols: default False, if True uses the quantity columns to fill the missing values
    :param use_altitude_col: default False, if True uses the altitude column to fill the missing values
    :param use_value_fob_col: default False, if True uses the value fob column to fill the missing values
    :param show_logs: default False, if True shows the logs of the process
    :return: dataframe with the missing values filled for each flight
    """
    df_complete = pd.DataFrame()
    i = 1
    start_time = time.time()
    for flight in df['id'].unique():
        loop_start_time = time.time()
        # We will filter the data for the flight
        df_flight = df[df['id'] == flight]

        # We will create a copy of the data frame
        df_flight_complete = df_flight.copy()

        # We create a list to iterate over the columns
        empty_list = []
        for col_num in range(1, 5):
            column_y = 'FUEL_USED_' + str(col_num)
            column_x = ['duration']
            if use_qty_cols:
                extra_col = 'VALUE_FUEL_QTY_FT' + str(col_num)
                column_x.append(extra_col)
            if use_altitude_col:
                column_x.append('FW_GEO_ALTITUDE')
            if use_value_fob_col:
                column_x.append('VALUE_FOB')
            df_flight_complete[column_y] = fill_missing_values(df_flight_complete, column_x, column_y)
        # We will concatenate the data frames
        df_complete = pd.concat([df_complete, df_flight_complete], axis=0)

        # We will print the progress
        if show_logs:
            ic(flight)
            progress_str = f'Progress: {round(i / df["id"].unique() * 100, 2)}%'
            ic(progress_str)
            i += 1
            loop_end_time = time.time()
            loop_duration = round(loop_end_time - loop_start_time, 2)
            loop_str = f'Loop duration: {loop_duration} seconds'
            ic(loop_str + "\n")

    if show_logs:
        total_time = time.time() - start_time
        ic(total_time)

    return df_complete


def add_fuel_columns(df,
                     col1='FUEL_DEPLETION',
                     col2='FUEL_USED_TOT'):
    """
    Function that adds the FUEL_DEPLETED and FUEL_USED_TOTAL columns to the dataframe
    :param df: data frame with the data
    :param col1: column name of first column to be used for the calculation of the error
    :param col2: column name of second column to be used for the calculation of the error
    :return: df: dataframe
    """
    # Add the max `VALUE_FOB` for each flight
    df['VALUE_FOB_MAX'] = df.groupby('id')['VALUE_FOB'].transform('max')

    # Subtract the `VALUE_FOB` from the `VALUE_FOB_MAX` for each flight
    df['FUEL_DEPLETION'] = df['VALUE_FOB_MAX'] - df['VALUE_FOB']

    # First we will calculate a total fuel used for each flight
    df['FUEL_USED_SUM'] = (df['FUEL_USED_1'] + df['FUEL_USED_2']
                           + df['FUEL_USED_3'] + df['FUEL_USED_4'])

    # We will now add the minimum `FUEL_USED_TOT` for each flight
    df['FUEL_USED_SUM_MIN'] = df.groupby('id')['FUEL_USED_SUM'].transform('min')

    # We will now subtract the `FUEL_USED_SUM_MIN` from the `FUEL_USED_SUM` for each flight for the `FUEL_USED_TOT`
    # column
    df['FUEL_USED_TOT'] = df['FUEL_USED_SUM'] - df['FUEL_USED_SUM_MIN']

    # Calculate the error between the `FUEL_DEPLETION` and the `FUEL_USED_TOT`
    df['FUEL_ERROR'] = df[col1] - df[col2]

    # Calculate `FUEL_ERROR_DIFF` as the difference between the `FUEL_ERROR` and the `FUEL_ERROR` of the previous row
    # Repeat the same for 'FUEL_USED_TOT' and 'FUEL_DEPLETION'
    df.sort_values(by=['id', 'UTC_TIME'], inplace=True)
    df['FUEL_ERROR_DIFF'] = df['FUEL_ERROR'] - df['FUEL_ERROR'].shift(1)
    df['FUEL_USED_TOT_DIFF'] = df['FUEL_USED_TOT'] - df['FUEL_USED_TOT'].shift(1)
    df['FUEL_DEPLETION_DIFF'] = df['FUEL_DEPLETION'] - df['FUEL_DEPLETION'].shift(1)
    df = df[df['duration'] != 0]

    # We will drop the auxiliary columns
    df.drop(columns=['VALUE_FOB_MAX', 'FUEL_USED_SUM', 'FUEL_USED_SUM_MIN'], inplace=True)

    return df


def statistical_tests(df,
                      column_name,
                      alpha=0.05):
    """
    Function that performs the ADF test and the one-sample t-test
    :param df:
    :param column_name:
    :param alpha: default 0.05
    :return: tests_dict: dictionary with the results of the tests
    """
    time_series = df[column_name].dropna()

    # Remove outliers outside the 0.01 and 0.99 quantiles
    # time_series = time_series[(time_series > time_series.quantile(0.01)) & (time_series < time_series.quantile(0.99))]

    # ADF test
    adf_result = adfuller(time_series)

    p_value_adf = adf_result[1]
    # H0: the series is not stationary
    # H1: the series is stationary
    adf_conclusion = 1 if p_value_adf < alpha else 0

    # We will add the lower and upper bounds of the 1-alpha confidence interval
    # We will use the mean and the standard deviation of the time series
    mean = time_series.mean()
    std = time_series.std()

    # We will add other useful statistics
    median = time_series.median()
    skew = time_series.skew()
    kurtosis = time_series.kurtosis()
    q1 = time_series.quantile(0.25)
    q3 = time_series.quantile(0.75)
    iqr = q3 - q1

    # bounds will be calculated using the parameter of the function alpha
    lower_bound = mean - norm.ppf(1 - alpha / 2) * std
    upper_bound = mean + norm.ppf(1 - alpha / 2) * std

    # We will add a boolean called 'contains_zero' that will be True if the zero is between the lower and upper bounds
    contains_zero = True if (lower_bound < 0) & (upper_bound > 0) else False

    # Leak detection
    leak_pred = False if contains_zero & (adf_conclusion == 1) else True

    tests_dict = {'id': df['id'].unique()[0], 'mean': mean, 'std': std,
                  # 'pval_adf': p_value_adf, 'result_adf': adf_conclusion,
                  'lower_bound': lower_bound, 'upper_bound': upper_bound,
                  'contains_zero': contains_zero, 'leak_pred': leak_pred,
                  'median': median, 'skew': skew, 'kurtosis': kurtosis,
                  'iqr': iqr}

    return tests_dict


def iterate_test(df,
                 column_name,
                 alpha=0.05,
                 iterable_column='id'):
    """
    Function that iterates through the flights and performs the statistical tests
    :param df: dataframe with the data
    :param column_name: column to perform the tests
    :param alpha: significance level
    :param iterable_column: column to iterate
    :return: tests_df: dataframe with the results of the tests
    """
    tests_df = pd.DataFrame()
    for flight in df[iterable_column].unique():
        df_flight = df[df[iterable_column] == flight]
        tests_dict = statistical_tests(df_flight, column_name, alpha)
        tests_df = pd.concat([tests_df, pd.DataFrame(tests_dict, index=[0])], axis=0)
    return tests_df


def simulate_flight(leak_bool=False,
                    id_num=0,
                    severity=0):
    """
    This function will simulate a flight with a fuel leak or not. It will have a random state that will determine the
    severity of the leak. The severity of the leak will influence if the leak just has a constant change of slope or
    if it has a sudden change of slope or an increase in the slope.
    :param leak_bool: Boolean to indicate if the flight will have a fuel leak or not
    :param id_num: id_num of the flight
    :param severity: Severity of the leak (1, 2, 3) each one with a different behavior
                        1: change in slope (40% of the cases)
                        2: sudden change in slope (45% of the cases)
                        3: increase in slope (15% of the cases)
    :return:
    """
    # We create the dataframe that will contain the simulated flight
    col_order = ['id', 'UTC_TIME', 'FUEL_USED_2', 'FUEL_USED_3', 'FUEL_USED_4',
                 'FW_GEO_ALTITUDE', 'FLIGHT_PHASE_COUNT', 'FUEL_USED_1',
                 'duration', 'FUEL_DEPLETION', 'FUEL_USED_TOT', 'FUEL_ERROR',
                 'FUEL_ERROR_DIFF', 'FUEL_USED_TOT_DIFF', 'FUEL_DEPLETION_DIFF']
    df_sim = pd.DataFrame(columns=col_order)

    # We instantiate the random state
    rs = np.random.uniform(0, 1)

    # Severity of the leak (1, 2, 3)
    # 0: no leak
    # 1: change in slope (40% of the cases)
    # 2: sudden change in slope (45% of the cases)
    # 3: increase in slope (15% of the cases)
    if leak_bool and severity == 0:
        if rs < 0.6:
            severity = 1
        elif rs <= 1:
            severity = 2
        else:
            severity = 3

    # Previously calculated values
    total_duration = int(np.random.uniform(10000, 30000))

    # We add the columns that do not depend on the leak
    df_sim['duration'] = range(0, total_duration)

    # We add the UTC_TIME column as 2023-01-01 00:00:00 plus the duration in seconds
    df_sim['UTC_TIME'] = pd.to_datetime('2023-01-01 00:00:00') + pd.to_timedelta(df_sim['duration'], unit='s')

    # We add the id column
    id_num = 'SIM' + str(id_num)
    if leak_bool:
        id_num = 'L' + str(severity) + '_' + id_num
    df_sim['id'] = id_num

    # Impute the a posteriori (previously calculated) hyperparameters for the mean and std of the distributions of
    # FUEL_USED_TOT_DIFF and FUEL_DEPLETION_DIFF
    # For the mean of the normal distribution we will get a simulation from a normal random variable
    mu_fuel_used_tot_diff_mean = 1.344
    mu_fuel_used_tot_diff_std = 0.2244
    mu_fuel_used_aposteriori = np.random.normal(mu_fuel_used_tot_diff_mean, mu_fuel_used_tot_diff_std)

    mu_fuel_depletion_diff_mean = 1.2039
    mu_fuel_depletion_diff_std = 0.1328
    mu_fuel_depletion_aposteriori = np.random.normal(mu_fuel_depletion_diff_mean, mu_fuel_depletion_diff_std)

    if mu_fuel_depletion_aposteriori < mu_fuel_used_aposteriori:
        mu_fuel_depletion_aposteriori = mu_fuel_used_aposteriori + np.random.uniform(0.1, 0.5)

    # For the std of the normal distribution we will get a simulation from a gamma random variable with the shape and
    # scale parameters calculated previously. We will use a gamma distribution because the std must be positive, and it
    # is a conjugate prior for the variance of a normal distribution
    sigma_fuel_depletion_diff_scale = 487.7244
    sigma_fuel_depletion_diff_shape = 0.0435
    sigma_fuel_depletion_aposteriori = np.random.gamma(sigma_fuel_depletion_diff_shape, sigma_fuel_depletion_diff_scale)

    sigma_fuel_used_tot_diff_scale = 23.6044
    sigma_fuel_used_tot_diff_shape = 0.0886
    sigma_fuel_used_aposteriori = np.random.gamma(sigma_fuel_used_tot_diff_shape, sigma_fuel_used_tot_diff_scale)

    # We will now simulate the FUEL_USED_TOT_DIFF
    fuel_used_tot_diff = np.random.normal(mu_fuel_used_aposteriori, sigma_fuel_used_aposteriori, total_duration)
    df_sim['FUEL_USED_TOT_DIFF'] = fuel_used_tot_diff

    # We will now simulate the FUEL_DEPLETION_DIFF, if the leak_bool is True, we will add a leak to the simulation
    # by multiplying the mean by a random variable from a uniform distribution between 1.5 and 15
    fuel_used_depletion_diff = np.random.normal(mu_fuel_depletion_aposteriori, sigma_fuel_depletion_aposteriori,
                                                total_duration)
    df_sim['FUEL_DEPLETION_DIFF'] = fuel_used_depletion_diff

    # In case of a leak we will overwrite the values of the FUEL_DEPLETION_DIFF column
    if leak_bool:
        if severity == 1:
            leak_multiplier = np.random.uniform(1.2, 2.5)
            mu_fuel_depletion_aposteriori = mu_fuel_depletion_aposteriori * leak_multiplier
            fuel_used_depletion_diff = np.random.normal(mu_fuel_depletion_aposteriori, sigma_fuel_depletion_aposteriori,
                                                        total_duration)
            df_sim['FUEL_DEPLETION_DIFF'] = fuel_used_depletion_diff
        elif severity == 2:
            leak_multiplier = np.random.uniform(1.2, 2.5)

            # We also simulate at which moment the leak will happen
            moment_leak = int(np.random.uniform(total_duration * 0.25, total_duration * 0.75))

            # We apply the multiplier only to the values after the moment of the leak
            mu_fuel_depletion_aposteriori = mu_fuel_depletion_aposteriori * leak_multiplier
            fuel_used_depletion_diff_leak = np.random.normal(mu_fuel_depletion_aposteriori,
                                                             sigma_fuel_depletion_aposteriori, total_duration)
            fuel_used_depletion_diff[moment_leak:] = fuel_used_depletion_diff_leak[moment_leak:]
            df_sim['FUEL_DEPLETION_DIFF'] = fuel_used_depletion_diff
        elif severity == 3:
            leak_multiplier = np.random.uniform(0.001, 0.8)
            df_sim['FUEL_DEPLETION_DIFF'] = df_sim['FUEL_DEPLETION_DIFF'] * leak_multiplier * df_sim['duration']

    # To calculate the FUEL_ERROR_DIFF we will use the FUEL_USED_TOT_DIFF and the FUEL_DEPLETION_DIFF
    df_sim['FUEL_ERROR_DIFF'] = df_sim['FUEL_USED_TOT_DIFF'] - df_sim['FUEL_DEPLETION_DIFF']

    # To calculate the accumulated columns, we will use the cumsum() function
    df_sim['FUEL_USED_TOT'] = df_sim['FUEL_USED_TOT_DIFF'].cumsum()
    df_sim['FUEL_DEPLETION'] = df_sim['FUEL_DEPLETION_DIFF'].cumsum()
    df_sim['FUEL_ERROR'] = df_sim['FUEL_ERROR_DIFF'].cumsum()

    # We add the FW_GEO_ALTITUDE as a normal variable centred in 30000 and std 1000
    df_sim['FW_GEO_ALTITUDE'] = np.random.normal(30000, 1000, total_duration)

    # We set FLIGHT_PHASE_COUNT to 8
    df_sim['FLIGHT_PHASE_COUNT'] = 8

    # We calculate 4 weight for FUEL_USED_i and assign them to the columns from FUEL_USED_TOT
    weights = np.random.uniform(0.1, 0.3, 4)
    weights = weights / weights.sum()

    df_sim['FUEL_USED_1'] = df_sim['FUEL_USED_TOT'] * weights[0]
    df_sim['FUEL_USED_2'] = df_sim['FUEL_USED_TOT'] * weights[1]
    df_sim['FUEL_USED_3'] = df_sim['FUEL_USED_TOT'] * weights[2]
    df_sim['FUEL_USED_4'] = df_sim['FUEL_USED_TOT'] * weights[3]

    # We add the severity of the leak
    df_sim['Leak_severity'] = severity

    # We add the label of the leak
    df_sim['Leak'] = leak_bool

    return df_sim


def df_to_timeseries(df,
                     id_col='id',
                     ts_col='FUEL_ERROR_DIFF',
                     n_obs=600,
                     group_min=False):
    """
    This function transforms a dataframe into a timeseries dataframe
    :param df:
    :param id_col:
    :param ts_col:
    :param n_obs:
    :return:
    """
    max_durations = df.groupby(id_col)['duration'].max()
    min_dur = min(max_durations)
    if n_obs > min_dur:
        n_obs = min_dur
    ts_list = list()
    id_list = list()
    for i in df[id_col].unique():
        df_iter = df[df[id_col] == i]
        duration_condition = df_iter['duration'] >= max(df_iter['duration']) - n_obs - 1
        df_iter_filtered = df_iter[duration_condition]
        ts = df_iter_filtered[ts_col].fillna(df_iter_filtered[ts_col].mean())
        # We will group for each 60 seconds, adding the mean of the values
        if group_min:
            ts = ts.groupby(ts.index // 60).mean()
        ts = ts.values
        # We will drop the last value of the timeseries since it might be a nan
        ts = ts[:-1]
        ts_list.append(ts)
        id_list.append(i)

    ts_df = pd.DataFrame(ts_list)
    ts_df.set_index(pd.Index(id_list), inplace=True)
    # Fill nans with the mean of the row
    ts_df = ts_df.apply(lambda x: x.fillna(x.mean()), axis=1)
    ts_df.reset_index(inplace=True)
    # We will drop the last column since it might be a nan
    ts_df.drop(columns=ts_df.columns[-1], inplace=True)
    ts_df['label'] = 0
    return ts_df
